// Deploy as haail-auth with JWT verification disabled: login is public;
// all account creation verifies the caller JWT and admin role explicitly.
import { createClient } from 'npm:@supabase/supabase-js@2';
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const reply=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers});
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response(null,{headers});
 if(req.method!=='POST')return reply({message:'Method not allowed'},405);
 try {
 const url=Deno.env.get('SUPABASE_URL')!,secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,key=Deno.env.get('SUPABASE_ANON_KEY')!;
 const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
 const body=await req.json(),username=String(body.username||'').trim().toLowerCase();
 if(!/^[a-z][a-z0-9_.-]{2,31}$/.test(username))return reply({message:'اسم المستخدم: 3–32 حرف إنكليزي أو رقم، يبدأ بحرف'},400);
 if(body.action==='login'){
  const {data:profile}=await admin.from('haail_users').select('user_id').eq('username',username).maybeSingle();
  let email='unknown-account@haail.invalid';
  if(profile){const {data}=await admin.auth.admin.getUserById(profile.user_id);email=data.user?.email||email;}
  const client=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data,error}=await client.auth.signInWithPassword({email,password:String(body.password||'')});
  if(error||!profile||!data.session)return reply({message:'اسم المستخدم أو كلمة المرور غير صحيحة'},401);
  return reply(data.session);
 }
 if(body.action!=='create')return reply({message:'عملية غير مسموحة'},400);
 const token=req.headers.get('Authorization')?.replace(/^Bearer\s+/i,'');
 if(!token)return reply({message:'غير مخوّل'},401);
 const {data:auth,error:authError}=await admin.auth.getUser(token);
 if(authError||!auth.user)return reply({message:'انتهت الجلسة؛ سجّل دخولك مجدداً'},401);
 const {data:owner}=await admin.from('haail_users').select('role').eq('user_id',auth.user.id).maybeSingle();
 if(owner?.role!=='admin')return reply({message:'إنشاء الحسابات للمدير فقط'},403);
 const password=String(body.password||''),name=String(body.name||'').trim();
 if(password.length<12||password.length>128||!name||name.length>100)return reply({message:'أدخل الاسم وكلمة مرور لا تقل عن 12 حرفاً'},400);
 const {data:existing}=await admin.from('haail_users').select('user_id').eq('username',username).maybeSingle();
 if(existing)return reply({message:'اسم المستخدم مستخدم مسبقاً'},409);
 const {data:created,error}=await admin.auth.admin.createUser({email:username+'@staff.haail.invalid',password,email_confirm:true});
 if(error||!created.user)return reply({message:'تعذر إنشاء الحساب؛ تحقق من الاسم ومتطلبات كلمة المرور'},400);
 const {error:profileError}=await admin.from('haail_users').insert({user_id:created.user.id,role:'employee',name,username});
 if(profileError){await admin.auth.admin.deleteUser(created.user.id);return reply({message:'تعذر حفظ الحساب؛ لم يتم تفعيل الصلاحية'},409);}
 await admin.from('haail_audit').insert({actor:auth.user.id,actor_name:'المدير',action:'create_employee',payload:{username,name,user_id:created.user.id}});
 return reply({success:true,username});
 }catch(_){return reply({message:'تعذر تنفيذ الطلب؛ تحقق من إعداد الخادم'},500);}
});
